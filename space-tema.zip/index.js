const links = document.querySelectorAll('.nav-list');
    
    links.forEach((link) => {
        link.addEventListener('click', () => {
            links.forEach((item) => {
                item.classList.remove('active');
            });
            
            link.classList.add('active');
        });
    });

function redirectToMoon() {
    window.location.href = "pagina-2.html";
}

function redirectToMars() {
    window.location.href = "pagina-3.html";
}

function redirectToEuropa() {
    window.location.href = "pagina-4.html";
}

function redirectToTitan() {
    window.location.href = "pagina-5.html";
}

function redirectToComander() {
    window.location.href = "pagina-6.html";
}

function redirectToSpecialist() {
    window.location.href = "pagina-7.html";
}

function redirectToPilot() {
    window.location.href = "pagina-8.html";
}

function redirectToEngineer() {
    window.location.href = "pagina-9.html";
}

function redirectToHome() {
    window.location.href = "index.html";
}

function redirectToDestination() {
    window.location.href = "pagina-2.html";
}

function redirectToCrew() {
    window.location.href = "pagina-6.html";
}

function redirectToTehnology() {
    window.location.href = "pagina-10.html";
}

function redirectToVehicle() {
    window.location.href = "pagina-10.html";
}

function redirectToSpceport() {
    window.location.href = "pagina-11.html";
}

function redirectToCapsule() {
    window.location.href = "pagina-12.html";
}

function redirectToexplore() {
    window.location.href = "pagina-2.html";
}